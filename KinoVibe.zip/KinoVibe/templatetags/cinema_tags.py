from django import template
from django.shortcuts import get_object_or_404

from KinoVibe.models import Genre, Videofile, Personaj, Review

register = template.Library()

@register.inclusion_tag('components/header/category.html')
def category():
    return {"genres" : Genre.objects.all()}
    


@register.simple_tag()
def genre_filter(movie_slug:None):
    genres = Videofile.objects.get(title=movie_slug).genre.all()
    return [genre.genre for genre in genres]

@register.simple_tag(name='movie_actores1')
def movie_actores(movie_slug:int)-> int:
    return movie_slug


@register.simple_tag(name='movie_actores')
def actore_films(movie_slug:str) -> str:
    movie = get_object_or_404(Videofile, slug=movie_slug)
    actores = Videofile.actores.all()
    actore_list = []
    for a  in actores:
        actore = Personaj.objects.get(fio=a)
        actore_list.append(actore)
    return  actore_list



@register.simple_tag()
def review_tag(movie_slug):
    review = Review.objects.filter(movie_slug=movie_slug)
    return review


